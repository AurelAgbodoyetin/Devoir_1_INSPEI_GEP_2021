#include <stdio.h>
#include <stdlib.h>


///Exercice 4
int main()
{
    /// Déclaration des variables
    int n, i, j, divs[100], ndiv = 0, isCarre = 0;

    /// Boucle pour assurer une bonne entrée de l'utilisateur
    do{
        printf("Entrez un entier : ");
        scanf("%d", &n);
        if(n <= 0){
            printf("Mauvaise entree, veuillez reessayer ! \n");
        }
    }while(n <=0 );

    /// Recherche des diviseurs du nombre entré par l'utilisateur
    for(i = 2; i <= n/2; i++){
        if(n % i == 0){
            divs[ndiv] = i;
            ndiv ++;
        }
    }


    /// Recherche de possible carré parfait parmi les diviseurs obtenus
    for(i = 0; i <= ndiv - 1; i++){
        for (j = 2; j <= divs[i]; j++){
            isCarre = divs[i] == j * j;
            if(isCarre) break;
        }
        if(isCarre) break;
    }


    /// Affichage du résultat
    if(isCarre){
        printf("%d n'est pas SquareFree car %d = %d^2 le divise", n, divs[i], j);
    }else{
        printf("%d est SquareFree", n);
    }

    return 0;
}

