#include <stdio.h>
#include <stdlib.h>


///Exercice 3
int main()
{
    int i, j;
    printf("\tI\t");

    for(i = 1; i <= 10; i++){
        printf("%d\t", i);
    }

    printf("\n");

    for(i = 0; i <= 100; i++){
        printf("-");
    }

    printf("\n");

    for(i = 1; i <= 10; i++){
        printf("%d\tI\t", i);
        for(j = 1; j <= 10; j++){
            printf("%d\t", i * j);
        }
        printf("\n");
    }
    return 0;
}
