#include <stdio.h>
#include <stdlib.h>

int main()
{
    int nrow, ncol, j, rep=0;
    float A[50][50];
    printf("Hello and welcome to this project. It allows you to check whether a matrix is symmetric or not.\n\n");

/** Matrix size verification*/
    do
    {
        printf("\nEnter the number of rows in the matrix : ");
        scanf("%d", &nrow);
        printf("Enter the number of columns in the matrix : ");
        scanf("%d", &ncol);
        if(nrow != ncol || nrow == 1)
        {
            if(nrow != ncol)
                printf("\nThe number of columns and rows are unequal, so it is impossible for the matrix to be symetric.\n");
            else
                printf("\nThe size of a matrix is at least 2.\n");

            printf("Do you want to restart ?\n  1-Yes\n  0-No\n  Answer : ");
            scanf("%d", &rep);
        }
    }while(rep == 1);

/**Is the matrix symmetric ?*/
    if(nrow == ncol && nrow != 1)
    {
        printf("\nEnter the matrix values by row.\n");
        for(int i=0; i<nrow; i++)
        {
            printf("line %d\n", i+1);
            for(j=0; j<ncol; j++)
            {
                printf("   a%d%d = ", i+1, j+1);
                scanf("%f", &A[i][j]);
            }
        }

        j = ncol;
        for(int i=0; i<nrow && j==ncol; i++)
            for(j=i+1; j<ncol && A[i][j] == A[j][i]; j++);

        if(j==ncol)
            printf("\nThe matrix is symmetric\n");
        else
            printf("\nThe matrix isn't symmetric\n");
    }
    printf("\n\n\t\tGOOD BYE\n\n");
    return 0;
}
