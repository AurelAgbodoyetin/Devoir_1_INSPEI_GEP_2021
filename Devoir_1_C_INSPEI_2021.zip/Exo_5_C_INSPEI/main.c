#include <stdio.h>
#include <stdlib.h>

int main()
{
    float n, nbrCatalan(float);
    printf("Hello and Welcome !!!\nThis code calculates the first n Catalan numbers.\n\n");
    printf("Enter a strictly positive integer : ");
    scanf("%f", &n);
    printf("\nThe first %.0f Catalan numbers are : \n", n);
    for(int i = 1; i<=n; i++)
        printf("    Cat(%d) = %.0f\n", i, nbrCatalan(i));

    printf("\n\n\t\tGOOD BYE\n\n");
    return 0;
}

/**Function to calculate Catalan numbers*/
float nbrCatalan(float n)
{
    if(n>1)
    {
        return (4*n - 6)/n * nbrCatalan(n-1);
    }
    return 1;
}
