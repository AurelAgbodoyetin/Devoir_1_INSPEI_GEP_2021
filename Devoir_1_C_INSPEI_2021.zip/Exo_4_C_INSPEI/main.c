#include <stdio.h>
#include <stdlib.h>

int main()
{
    float cap0 = 25000, cap, t=4;  /* cap0 => capital initial
                                            * cap => montant dans le compte de l'ami chaque année
                                            * t => taux d'intérêt
                                            */
    int n;  /* n => le comteur d'année*/
    printf("Hello and welcome to this program !!!\n");
    printf("It allows you to calculate the number of years it takes to triple\n");
    printf("an initial capital of %.0f with an annual interest rate of %.0f percent.\n", cap0, t);

    for(n=0, cap=cap0; cap < 3*cap0; cap += cap*0.04*++n);

    printf("\nIt takes %d years to get triple the capital\n", n);

    printf("\n\n\t\tGOOD BYE\n\n");
    return 0;
}
